// Barclays demo website - Step 3: basic interactions

document.addEventListener('DOMContentLoaded', function () {

  // Underline the menu link for the page the visitor is on
  var currentPage = window.location.pathname.split('/').pop() || 'index.html';

  document.querySelectorAll('.main-nav a').forEach(function (link) {
    if (link.getAttribute('href').endsWith(currentPage)) {
      link.style.textDecoration = 'underline';
      link.setAttribute('aria-current', 'page');
    }
  });

  // Keep the footer year up to date
  var footerText = document.querySelector('.site-footer p');
  if (footerText) {
    footerText.innerHTML = footerText.innerHTML.replace(/\d{4}/, new Date().getFullYear());
  }

});
